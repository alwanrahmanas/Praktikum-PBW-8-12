<?php
    include 'connection.php';
    
    $id = $_GET['noId'];
    if(isset($_GET['pesan'])) {
        $pesan = $_GET['pesan'];
        echo "
            <script>    
                alert('",$pesan,"');
            </script>
            ";
    }  else {
        $pesan = "";
    }
    if(isset($_GET['berhasil'])) {
        echo "
            <script>
                alert('Edit Akun Berhasil!');
                document.location.href = 'controller.php?hlm=anggota';
            </script>
            ";
    }
    $sql = mysqli_query($koneksi, "SELECT * FROM pengguna WHERE noId = '$id'");
    while($member = mysqli_fetch_assoc($sql)) {
        $username = isset($_GET['username']) ? $_GET['username'] : $member['nama_pengguna']; 
        $email = isset($_GET['email']) ? $_GET['email'] : $member['email'];
        $pswd1 = isset($_GET['pswd1']) ? $_GET['pswd1'] : $member['password'];
        $pswd2 = isset($_GET['pswd2']) ? $_GET['pswd2'] : $member['password'];
        $fname = isset($_GET['fname']) ? $_GET['fname'] : $member['nama_depan'];
        $lname = isset($_GET['lname']) ? $_GET['lname'] : $member['nama_belakang'];
        $jk = isset($_GET['jk']) ? $_GET['jk'] : $member['jenis_kelamin'];
        $alamat = isset($_GET['alamat']) ? $_REQUEST['alamat'] : "";
    }
?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Buat Akun</title>
        <link rel="stylesheet" href="CSS/CreateAccount.css">
    </head>
    <body>
        <div class="buatakun">
            <h1>Edit Akun SinauWeb</h1>
            <h3><?php echo $pesan ?></h3>
            <form action="edit_process.php" method="POST">
                <input type="hidden" name="noId" value="<?= $id ?>">
                <label for="">Username</label>
                <input type="text" name="username" value="<?= $username; ?>" maxlength="20"autofocus onkeypress="nextField(event, 'email')">
                <label for="">Alamat Email</label>
                <input type="email" name="email" value="<?= $email; ?>">
                <label for="">Password</label>
                <input type="password" name="pswd1" value="<?= $pswd1; ?>" >
                <label for="">Konfirmasi Password</label>
                <input type="password" name="pswd2" value="<?= $pswd2; ?>">
                <label for="">Nama</label>
                <div class="nama">
                    <input type="text" name="fname" placeholder="Nama Depan" value="<?= $fname; ?>">
                    <input type="text" name="lname" placeholder="Nama Belakang" value="<?= $lname; ?>">
                </div>
                <label for="">Jenis Kelamin</label>
                <div class="jk">
                    <input type="radio" name="jk" id="lk" value="Laki-laki" <?php if($jk == "Laki-laki") { echo 'checked';} ?>><label for="lk">Laki-laki</label>
                    <input type="radio" name="jk" id="pr" value="Perempuan" <?php if($jk == "Perempuan") { echo 'checked';} ?>><label for="pr">Perempuan</label>
                </div>
                <label for="">Alamat</label>
                <textarea name="alamat" cols="30" rows="10"></textarea>
                <input type="hidden" name="level" value="user">
                <div class="btn">
                    <input type="submit" name="edit" value="Edit Akun" id="submit">
                </div>
            </form>
        </div>
    </body>
</html>