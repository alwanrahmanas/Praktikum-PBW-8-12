<?php
session_start();
if(empty($_SESSION['noId'])){
	$_SESSION['error'] = '<div style="text-align:center;margin-bottom:20px;"><strong style="font-size:20px;">ERROR!</strong><br><p>Username dan Password tidak valid</p></div>';
	header('Location: ./login.php');
	die();
} else {
	include "connection.php";
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="CSS/Menu.css">
    <title>SinauWeb</title>
	<script>
		function ganti(file) {
    	document.getElementById('filetampil').src = "FileMateri/"+file;
	}
	</script>
</head>
<body>
    <?php include "menu.php"?>

    <?php
		if(isset($_REQUEST['hlm'])){

			$hlm = $_REQUEST['hlm'];

			switch($hlm){
				case 'anggota':
					include "anggota.php";
					break;
				case 'materi':
					include "materi.php";
					break;
				case 'gallery':
					include "gallery.php";
					break;
			}
		} else {
    ?>
	<div class="home">
		<div class="bg"></div>
		<div class="penjelasan">
			<h1>Hello <?= $_SESSION['username']; ?></h1>
			<h2>Selamat datang di SinauWeb</h2>
		</div>
	</div>
	
	<?php
		}
	?>
	<footer style="color:white;text-align: center;font-size:20px; background-color:rgb(76,76,76);">Copyright &copy; Muhammad Abdurrofi. All right reserved</footer>
</body>
</html>
<?php
}
?>