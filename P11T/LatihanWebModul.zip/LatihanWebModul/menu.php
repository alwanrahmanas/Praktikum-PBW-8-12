<?php
    if(!empty( $_SESSION['noId'] ) ){
    include "connection.php";
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="CSS/Menu.css">
    
    <title>Home</title>
</head>
<body>
    <nav>
        <div class="logo">
            <h3><a href="index.php">SinauWeb</a></h3>
        </div>
        <ul class="link">
            <li><a href="controller.php">Home</a></li>
            <li><a href="?hlm=anggota">Member</a></li>
            <li><a href="?hlm=materi">Theory</a></li>
            <li><a href="?hlm=gallery">Gallery</a></li>   
        </ul>

        <div class="io">
            <input type="checkbox">
            <div class="in">
                <a href="#" id="nama"><?php echo $_SESSION['username'] ?></a>
            </div>
            <ul>
                <li><a href="logout.php">Logout</a></li>
            </ul>
        </div>

        <div class="menu-toggle">
            <input type="checkbox">
            <span></span>
            <span></span>
            <span></span>
        </div>
    </nav>
    <footer style="color:white;text-align: center;font-size:20px; background-color:rgb(76,76,76);">&copy; Muhammad Abdurrofi</footer>
    <script src="JS/navbar.js"></script>
</body>
</html>
<?php
} else {
	header("Location: ./login.php");
	die();
}
?>