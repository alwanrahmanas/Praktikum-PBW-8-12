var keyword = document.getElementById('keyword');
var container = document.getElementById('tabel');

keyword.addEventListener('keyup', function() {
    var xhr = new XMLHttpRequest();
    xhr.onreadystatechange = function () {
        if(xhr.readyState == 4 && xhr.status == 200) {
            container.innerHTML = xhr.responseText;
        } 
    }
    xhr.open('GET', 'AJAX/materi.php?keyword=' + keyword.value, true);
    xhr.send();
});

keyword.addEventListener('', function() {
    var xhr = new XMLHttpRequest();
    xhr.onreadystatechange = function () {
        if(xhr.readyState == 4 && xhr.status == 200) {
            container.innerHTML = xhr.responseText;
        } 
    }
    xhr.open('GET', 'AJAX/materi.php?keyword=' + keyword.value, true);
    xhr.send();
});