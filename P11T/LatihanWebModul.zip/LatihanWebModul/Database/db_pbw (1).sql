-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 23, 2021 at 03:20 AM
-- Server version: 10.4.17-MariaDB
-- PHP Version: 8.0.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_pbw`
--

-- --------------------------------------------------------

--
-- Table structure for table `materi`
--

CREATE TABLE `materi` (
  `id_materi` int(11) NOT NULL,
  `judul_materi` varchar(100) NOT NULL,
  `nama_materi` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `materi`
--

INSERT INTO `materi` (`id_materi`, `judul_materi`, `nama_materi`) VALUES
(1, 'Overview', 'file_1.pdf'),
(2, 'HTML Part 1', 'file_2.pdf'),
(3, 'HTML Part 2', 'file_3.pdf'),
(4, 'HTML Part 3', 'file_4.pdf'),
(5, 'HTML Part 4', 'file_5.pdf'),
(6, 'CSS Part 1', 'file_6.pdf'),
(7, 'CSS Part 2', 'file_7.pdf'),
(8, 'CSS Part 3', 'file_8.pdf'),
(9, 'CSS Part 4', 'file_9.pdf'),
(10, 'JavaScript Part 1', 'file_10.pdf'),
(11, 'JavaScript Part 2', 'file_11.pdf'),
(12, 'JavaScript Part 3', 'file_12.pdf'),
(13, 'JavaScript Part 4', 'file_13.pdf'),
(14, 'JavaScript Part 5', 'file_14.pdf'),
(15, 'JavaScript Part 6', 'file_15.pdf'),
(16, 'JavaScript Part 7', 'file_16.pdf'),
(17, 'JavaScript Part 8', 'file_17.pdf'),
(18, 'PHP Part 1', 'file_18.pdf'),
(19, 'PHP Part 2', 'file_19.pdf'),
(20, 'PHP Part 3', 'file_20.pdf'),
(21, 'PHP Part 4', 'file_21.pdf'),
(22, 'PHP Part 5', 'file_22.pdf'),
(23, 'PHP Part 6', 'file_23.pdf'),
(24, 'PDO', 'file_24.pdf'),
(25, 'Ajax', 'file_25.pdf'),
(26, 'REST Part 1', 'file_26.pdf');

-- --------------------------------------------------------

--
-- Table structure for table `pengguna`
--

CREATE TABLE `pengguna` (
  `noId` int(10) NOT NULL,
  `nama_pengguna` varchar(20) NOT NULL,
  `email` varchar(40) NOT NULL,
  `password` varchar(50) NOT NULL,
  `nama_depan` varchar(20) NOT NULL,
  `nama_belakang` varchar(20) NOT NULL,
  `jenis_kelamin` char(9) NOT NULL,
  `alamat` text NOT NULL,
  `level` varchar(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `pengguna`
--

INSERT INTO `pengguna` (`noId`, `nama_pengguna`, `email`, `password`, `nama_depan`, `nama_belakang`, `jenis_kelamin`, `alamat`, `level`) VALUES
(13, 'rofi', 'rofi01@gmail.com', 'db63417384095d63d569ef69c6c8371d', 'Muhammad', 'Abdurrofi', 'Laki-laki', 'Jalan Pancasila No 35 Rt 11/04', 'admin'),
(14, 'muhrofi', 'muhrofi01@gmail.com', 'db63417384095d63d569ef69c6c8371d', 'Muhammad', 'Abdurrofi', 'Laki-laki', 'Jalan Pancasila No 35 Rt 11/04', 'admin'),
(22, 'rofimuh', 'rofimuh01@gmail.com', 'db63417384095d63d569ef69c6c8371d', 'Muhammad', 'Abdurrofi', 'Laki-laki', 'Jalan Pancasila No 35 Rt 11/04', 'admin');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `materi`
--
ALTER TABLE `materi`
  ADD PRIMARY KEY (`id_materi`);

--
-- Indexes for table `pengguna`
--
ALTER TABLE `pengguna`
  ADD PRIMARY KEY (`noId`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `materi`
--
ALTER TABLE `materi`
  MODIFY `id_materi` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;

--
-- AUTO_INCREMENT for table `pengguna`
--
ALTER TABLE `pengguna`
  MODIFY `noId` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=44;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
