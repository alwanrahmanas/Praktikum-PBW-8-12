<?php
    if(!empty($_SESSION['noId'])) {
        if(isset($_REQUEST['berhasil'])) {
            echo '<script>
                    alert("File Berhasil Terupload!!");
                </script>';
        }
?>
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Document</title>
        <link rel="stylesheet" href="CSS/materi.css">
    </head>
    <body style="overflow-y: unset;">
        <?php
            if($_SESSION['level'] == "admin") {
        ?>
        <div class="upload">
            <h2>Upload File Materi</h2>
            <form action="input_file.php" method="post" enctype="multipart/form-data">
                <input type="text" name="judulfile" placeholder="Masukkan Judul File...">
                <input type="file" name="namafile" value="Upload File">
                <input type="submit" id="submit" name="submit" style="width: 100px;">    
            </form>
        </div>
        <?php
            }
        ?>
        <div class="isi">
            <div class="bg">
                <div class="cari">
                    <h1>Theory</h1>
                    <input type="text" name="keyword" id="keyword"  placeholder="Masukkan keyword pencarian..." autocomplete="off">       
                </div>
                <div id="tabel">
                </div>
            </div>
            <div class="tampilfile">
                <iframe id="filetampil" src="" width="950px" height="700px"></iframe>
            </div>
        </div>
        <script src="JS/search_materi.js"></script>
    </body>
    </html>
<?php
    } 
?>