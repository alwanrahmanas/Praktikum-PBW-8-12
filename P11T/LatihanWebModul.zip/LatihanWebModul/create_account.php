<?php
    if(isset($_GET['pesan'])) {
        $pesan = $_GET['pesan'];
        echo "
            <script>    
                alert('",$pesan,"');
            </script>
            ";
    }  else {
        $pesan = "";
    }
    if(isset($_GET['berhasil'])) {
        echo "
            <script>
                alert('Registrasi Akun Berhasil!');
                document.location.href = 'login.php';
            </script>
            ";
    }
        $username = isset($_GET['username']) ? $_GET['username'] : ""; 
        $email = isset($_GET['email']) ? $_GET['email'] : "";
        $pswd1 = isset($_GET['pswd1']) ? $_GET['pswd1'] : "";
        $pswd2 = isset($_GET['pswd2']) ? $_GET['pswd2'] : "";
        $fname = isset($_GET['fname']) ? $_GET['fname'] : "";
        $lname = isset($_GET['lname']) ? $_GET['lname'] : "";
        $lname = isset($_GET['jk']) ? $_GET['jk'] : "";
        $alamat = isset($_GET['alamat']) ? $_REQUEST['alamat'] : "";
?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Buat Akun</title>
        <link rel="stylesheet" href="CSS/CreateAccount.css">
    </head>
    <body>
        <div class="buatakun">
            <h1>Buat Akun SinauWeb</h1>
            <h2>Sudah punya Akun SinauWeb? <a href="login.php">Masuk</a></h2>
            <h3><?php echo $pesan ?></h3>
            <form action="create_process.php" method="POST">
                <label for="">Username</label>
                <input type="text" name="username" value="<?php echo $username ?>" placeholder="Maksimal 20 karakter" maxlength="20"autofocus autocomplete="off" onkeypress="nextField(event, 'email')">
                <label for="">Alamat Email</label>
                <input type="email" name="email" value="<?php echo $email ?>">
                <label for="">Password</label>
                <input type="password" name="pswd1" value="<?php echo $pswd1 ?>" >
                <label for="">Konfirmasi Password</label>
                <input type="password" name="pswd2" value="<?php echo $pswd2 ?>">
                <label for="">Nama</label>
                <div class="nama">
                    <input type="text" name="fname" placeholder="Nama Depan" value="<?php echo $fname ?>">
                    <input type="text" name="lname" placeholder="Nama Belakang" value="<?php echo $lname ?>">
                </div>
                <label for="">Jenis Kelamin</label>
                <div class="jk">
                    <input type="radio" name="jk" id="lk" value="Laki-laki"><label for="lk" style="font-weight: 500;">Laki-laki</label>
                    <input type="radio" name="jk" id="pr" value="Perempuan"><label for="pr" style="font-weight: 500;">Perempuan</label>
                </div>
                <label for="">Alamat</label>
                <textarea name="alamat" cols="30" rows="10" value="<?php echo $alamat ?>"></textarea>
                <input type="hidden" name="level" value="user">
                <div class="btn">
                    <input type="submit" name="buat" value="Buat Akun" id="submit">
                </div>
            </form>
        </div>
    </body>
</html>