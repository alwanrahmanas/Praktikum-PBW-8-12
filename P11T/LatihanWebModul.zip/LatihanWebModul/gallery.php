<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="CSS/isi.css">
</head>
<body style="overflow-y: unset;">
<div class="content">
            <div class="bg">
                <div class="cari">
                    <h1>Gallery</h1>
                </div>
            </div>
            <div class="isi">
                <div class="semuagambar">
                    <img src="img/gambar-image- (1).jpg" alt="Rofi" title="Rofi">
                    <img src="img/gambar-image- (2).jpg" alt="Yoka" title="Yoka">
                    <img src="img/gambar-image- (3).jpg" alt="Umi" title="Umi">
                    <img src="img/gambar-image- (4).jpg" alt="Wilda" title="Wilda">
                    <img src="img/gambar-image- (5).jpg" alt="Dafi" title="Dafi">
                    <img src="img/gambar-image- (8).jpg" alt="Novril" title="Novril">
                    <img src="img/gambar-image- (6).jpg" alt="Daffa" title="Daffa">
                    <img src="img/gambar-image- (7).jpg" alt="Della" title="Della">
                    <img src="img/gambar-image- (9).jpg" alt="Rizka" title="Rizka">
                    <img src="img/gambar-image- (10).jpg" alt="Billy" title="Billy">
                    <img src="img/gambar-image- (11).jpg" alt="Rosyid&Novril" title="Rosyid & Novril">
                    <img src="img/gambar-image- (12).jpg" alt="Rofi&Ilman" title="Rofi & Ilman">
                </div>
            </div>
        </div>
</body>
</html>