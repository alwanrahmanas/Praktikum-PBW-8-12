<?php
    session_start();

    // jika ada session, maka akan diarahkan ke halaman dashboard admin
    if(isset($_SESSION['noId'])){
        header("Location: ./controller.php");
        die();
    }

    include "connection.php";
?>

<!DOCTYPE html>
<html lang="en-GB">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Login</title>
        <link rel="stylesheet" href="CSS/Login.css">
    </head>
    <body>
        <?php
            if(isset($_REQUEST['login'])) {
                $username = $_REQUEST['username'];
                $password = md5($_REQUEST['password']);

                $sql = mysqli_query($koneksi, "SELECT noId, nama_pengguna, nama_depan, nama_belakang, level FROM pengguna WHERE nama_pengguna='$username' AND password='$password'");

                if($sql) {
                    list($noId, $username, $fname, $lname, $level) = mysqli_fetch_array($sql);
                    $_SESSION['noId'] = $noId;
                    $_SESSION['username'] = $username;
                    $_SESSION['fname'] = $fname;
                    $_SESSION['lname'] = $lname;
                    $_SESSION['level'] = $level;
                    header("Location: ./controller.php");
                    die();
                } else {
                    $_SESSION['error'] = '<div style="text-align:center; color:white; margin-bottom:20px;"><strong style="font-size:20px;">ERROR!</strong><br><p>Username dan Password tidak valid</p></div>';
                    header("Location: ./login.php");
                    die();
                }
                
            } else {
        ?>
        <div class="login">
            <h1>Login Form</h1>
            <div class="masukakun">
                <form action="" method="post">
                    <input type="text" name="username" id="username" placeholder="Username" autofocus autocomplete="off" onkeypress="nextField(event, 'pswd')" title="Please enter your username"> 
                    <input type="password" name="password" id="pswd" placeholder="Password" title="Please enter your password">
                    <div class="btn">
                        <input type="submit" name="login" id="submit" value="LOGIN">
                    </div>
                    <div>
                        <?php
                            if(isset($_SESSION['error'])){
                                $err = $_SESSION['error'];
                                echo $err;
                                unset($_SESSION['error']);
                            }
                        ?>
                    </div>
                </form>
        <?php
            }
        ?>
            </div>
            <div class="buatakun">
                <h2 style="margin-bottom: 15px;">Belum mempunyai akun?</h2>
                <div class="btn">
                    <a href="create_account.php"><input type="button" value="Buat Akun"></a>
                </div>
            </div>
        </div>
        <script src="JS/asal.js"></script>
    </body>
</html>