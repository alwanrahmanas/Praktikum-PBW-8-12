<?php
    if(!empty($_SESSION['noId'])) {
        include 'connection.php';
?>  
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Document</title>
        <link rel="stylesheet" href="CSS/isi.css">
    </head>
    <body style="overflow-y: unset;">
        <div class="content">
            <div class="bg">
                <div class="cari">
                    <h1>Member</h1>
                    <input type="text" name="keyword" id="keyword"  placeholder="Masukkan keyword pencarian..." autocomplete="off">       
                </div>
            </div>
            <div class="isi">
                <div id="tabel">
                    <table>
                        <tr>
                            <th style="width: 5%;">No</th>
                            <th style="width: 10%;">Username</th>
                            <th style="width: 20%;">Email</th>
                            <th style="width: 10%;">Nama Depan</th>
                            <th style="width: 10%;">Nama Belakang</th>
                            <th style="width: 10%;">Jenis Kelamin</th>
                            <th style="width: 20%;">Alamat</th>
                            <th style="width:5%;">Aksi</th>
                        </tr>                        
                        <?php
                            $sql = mysqli_query($koneksi, "SELECT * FROM pengguna");
                            if(mysqli_num_rows($sql) > 0) {
                                $no = 0;
                                while($row = mysqli_fetch_array($sql)){
                                    $no++;
                        ?>
                        <tr>
                            <td><?php echo $no ?></td>
                            <td><?php echo $row['nama_pengguna'] ?></td>
                            <td><?php echo $row['email'] ?></td>
                            <td><?php echo $row['nama_depan'] ?></td>
                            <td><?php echo $row['nama_belakang'] ?></td>
                            <td><?php echo $row['jenis_kelamin'] ?></td>
                            <td><?php echo $row['alamat'] ?></td>
                            <div class="aksi" id="aksi">
                                <?php
                                    if($_SESSION['level'] == 'admin') {
                                ?>
                                        <td style="border-bottom: none;"><a href="edit_account.php?noId=<?php echo $row['noId']; ?>" >Edit</a><br><a href="delete_process.php?noId=<?php echo $row['noId']; ?>" onclick="return confirm('Yakin untuk menghapus data??')">Hapus</a></td>
                                <?php
                                    } elseif($row['noId'] == $_SESSION['noId']) {
                                ?>
                                        <td style="border-bottom: none;"><a href="edit_account.php?noId=<?php echo $row['noId']; ?>">Edit</a></td>
                                <?php
                                    }
                                ?>
                            </div>
                        </tr>
                            <?php
                                }
                            ?>
                        <?php
                            }
                        ?>
                    </table>
                </div>
            </div>
        </div>
        
        <script src="JS/search_member.js"></script>
    </body>
    </html>
<?php
    } 
?>