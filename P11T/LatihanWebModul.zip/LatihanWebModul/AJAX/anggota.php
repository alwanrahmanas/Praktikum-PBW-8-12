<?php
    session_start();
    include '../connection.php';
    $keyword = $_GET['keyword'];
?>
                <table>
                    <tr>
                        <th>No</th>
                        <th>Username</th>
                        <th>Email</th>
                        <th>Nama Depan</th>
                        <th>Nama Belakang</th>
                        <th>Jenis Kelamin</th>
                        <th>Alamat</th>
                        <?php
                            if($_SESSION['level'] == 'admin') {
                        ?>
                                <th>Aksi</th>
                        <?php
                            }
                        ?>
                    </tr>
                    <?php
                        $sql = mysqli_query($koneksi, "SELECT * FROM pengguna WHERE nama_pengguna LIKE '%$keyword%' OR email LIKE '%$keyword%' OR nama_depan LIKE '%$keyword%' OR nama_belakang LIKE '%$keyword%'");
                        if(mysqli_num_rows($sql) > 0){
                            $no = 0;
                            while($row = mysqli_fetch_array($sql)){
                                $no++;
                    ?>
                    <tr>
                        <td><?php echo $no ?></td>
                        <td><?php echo $row['nama_pengguna'] ?></td>
                        <td><?php echo $row['email'] ?></td>
                        <td><?php echo $row['nama_depan'] ?></td>
                        <td><?php echo $row['nama_belakang'] ?></td>
                        <td><?php echo $row['jenis_kelamin'] ?></td>
                        <td><?php echo $row['alamat'] ?></td>
                        <div class="aksi">
                            <?php
                                if($_SESSION['level'] == 'admin') {
                            ?>
                                    <td><a href="edit_account.php?noId=<?php echo $row['noId']; ?>">Edit</a> | <a href="delete_process.php?noId=<?php echo $row['noId']; ?>" onclick="return confirm('Yakin untuk menghapus data??')">Hapus</a></td>
                            <?php
                                } elseif($row['noId'] == $_SESSION['noId']) {
                            ?>
                                    <td><a href="edit_account.php?noId=<?php echo $row['noId']; ?>">Edit</a></td>
                            <?php
                                }
                            ?>
                        </div>
                    </tr>
                        <?php
                            }
                        ?>
                    <?php
                        }
                    ?>
                </table>