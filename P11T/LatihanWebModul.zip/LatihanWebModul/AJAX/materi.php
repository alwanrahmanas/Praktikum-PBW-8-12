<?php
    session_start();
    include '../connection.php';
    $keyword = $_GET['keyword'];
    if(!empty($keyword)) {
?>
                    <table>
                        <tr>
                            <th>No</th>
                            <th colspan="2">Materi</th>
                        </tr>
                        <?php
                            $sql = mysqli_query($koneksi, "SELECT * FROM materi WHERE judul_materi LIKE '%$keyword%'");
                            if(mysqli_num_rows($sql) > 0){
                                $no = 0;
                                while($row = mysqli_fetch_array($sql)){
                                    $no++;
                        ?>
                        <tr>
                            <td><?php echo $no ?></td>
                            <td><?php echo $row['judul_materi'] ?></td>
                            <td style="text-align: center;"><input id="btn" type="button" value="Tampil File" onclick="ganti('<?php echo $row['nama_materi']?>');"></td>
                            <?php
                                if($_SESSION['level'] == "admin") {
                            ?>
                                    <td><a href="delete_process.php?id_materi=<?= $row['id_materi']?>" id="hapus">Hapus</a></td>
                            <?php
                                }
                            ?>
                        </tr>
                            <?php
                                }
                            ?>
                        <?php
                            }
                        ?>
                    </table>
<?php
    }
?>