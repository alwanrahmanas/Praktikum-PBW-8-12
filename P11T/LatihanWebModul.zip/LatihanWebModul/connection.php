<?php
    $db_host = "localhost";
    $db_user = "rofi";
    $db_psw = "";
    $db_name = "test4";
    $koneksi = mysqli_connect($db_host, $db_user, $db_psw, $db_name);

    if (!$koneksi) {
        die("Koneksi database gagal: " . mysqli_connect_error());
    }
?>