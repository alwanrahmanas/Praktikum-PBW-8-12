<?php
    if(!isset($_REQUEST['buat'])) {
        header("Location: create_account.php");
    }

    include 'connection.php';

    $username = trim($_REQUEST['username']);
    $email = trim($_REQUEST['email']);
    $pswd1 = trim($_REQUEST['pswd1']);
    $pswd2 = trim($_REQUEST['pswd2']);
    $fname = trim($_REQUEST['fname']);
    $lname = trim($_REQUEST['lname']);
    $jk = trim($_REQUEST['jk']);
    $alamat = trim($_REQUEST['alamat']);
    $level = $_REQUEST['level'];

    $query_username = "username=".urlencode($username);
    $query_email = "email=".urlencode($email);
    $query_pswd1 = "pswd1=".urlencode($pswd1);
    $query_pswd2 = "pswd2=".urlencode($pswd2);
    $query_fname = "fname=".urlencode($fname);
    $query_lname = "lname=".urlencode($lname);
    $query_jk = "jk=".urlencode($jk);
    $query_alamat = "alamat=".urlencode($alamat);
    $isi_form = "&$query_username&$query_email&$query_pswd1&$query_pswd2&$query_fname&$query_lname&$query_jk&$query_alamat";


    if(empty($username)) {
        $pesan = urlencode("Username harus diisi");
        header("Location: create_account.php?pesan={$pesan}{$isi_form}");
        die();
    }

    $sql = mysqli_query($koneksi, "SELECT nama_pengguna FROM pengguna");
    if(mysqli_num_rows($sql) > 0) {
        while($row = mysqli_fetch_assoc($sql)){
            if(strcmp($username, $row['nama_pengguna']) == 0) {
                $pesan = urlencode("Username sudah dipakai");
                header("Location: create_account.php?pesan={$pesan}{$isi_form}");
                die();
            }
        }
    }

    if(empty($email)) {
        $pesan = urlencode("Email harus diisi");
        header("Location: create_account.php?pesan={$pesan}{$isi_form}");
        die();
    }

    if(empty($pswd1)) {
        $pesan = urlencode("Password harus diisi");
        header("Location: create_account.php?pesan={$pesan}{$isi_form}");
        die();
    }
        
    $jumlahkarakter = strlen($pswd1);
    if($jumlahkarakter <= 5){
        $pesan = urlencode("Password minimal terdiri dari 6 karakter");
        header("Location: create_account.php?pesan={$pesan}{$isi_form}");
        die();
    }


    if(strcmp($pswd1, $pswd2) != 0) {
        $pesan = urlencode("Password harus sama");
        header("Location: create_account.php?pesan={$pesan}{$isi_form}");
        die();
    }

    $pswd = md5($pswd1);

    if(empty($fname)) {
        $pesan = urlencode("Nama depan harus diisi");
        header("Location: create_account.php?pesan={$pesan}{$isi_form}");
        die();
    }

    if(!preg_match('/^[a-zA-Z\s]+$/', $fname)){
        $pesan = urlencode("Nama harus terdiri dari huruf dan spasi");
        header("Location: create_account.php?pesan={$pesan}{$isi_form}");
        die();
    }


    if(empty($lname)) {
        $pesan = urlencode("Nama belakang harus diisi");
        header("Location: create_account.php?pesan={$pesan}{$isi_form}");
        die();
    }

    if(!preg_match('/^[a-zA-Z\s]+$/', $lname)){
        $pesan = urlencode("Nama harus terdiri dari huruf dan spasi");
        header("Location: pjjPert4(daftarsekarang).php?pesan={$pesan}{$isi_form}");
        die();
    }

    if(empty($jk)) {
        $pesan = urlencode("Jenis kelamin harus pilih salah satu");
        header("Location: create_account.php?pesan={$pesan}{$isi_form}");
        die();
    }

    if(empty($alamat)) {
        $pesan = urlencode("Alamat harus diisi");
        header("Location: create_account.php?pesan={$pesan}{$isi_form}");
        die();
    }

    mysqli_query($koneksi, "INSERT INTO pengguna VALUES( '','$username', '$email', '$pswd', '$fname', '$lname', '$jk', '$alamat', '$level')");
    
    $berhasil = trim("berhasil");
    $query_berhasil = "berhasil=".urlencode($berhasil);
    $isi_form = "&$query_berhasil";
    header("Location: create_account.php?{$isi_form}");

    $koneksi = null;
    die();
?>