<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="CSS/Menu.css">
    <title>SinauWeb</title>
</head>
<body>
    <nav>
        <div class="logo">
            <h3><a href="index.php">SinauWeb</a></h3>
        </div>
        <ul class="link">
            <li><a href="#home" class="active">Home</a></li>
            <li><a href="#about">About</a></li>
            <li><a href="#gallery">Gallery</a></li>
            <li><a href="#contact">Contact</a></li>   
        </ul>

        <div class="io">
            <div class="in" style="overflow: unset;">
                <a href="login.php" id="login">Login</a>
            </div>
        </div>

        <div class="menu-toggle">
            <input type="checkbox">
            <span></span>
            <span></span>
            <span></span>
        </div>
    </nav>

    <section class="home" id="home">
        <div class="penjelasan">
            <h1>SinauWeb</h1>
            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Odit quae libero natus reprehenderit praesentium assumenda ut, expedita ducimus ratione nihil voluptatem. Commodi a deserunt fugit eaque quis molestias asperiores omnis.
                Lorem, ipsum dolor sit amet consectetur adipisicing elit. Accusamus aspernatur ipsa deserunt! Quibusdam excepturi magnam fugiat quia unde consectetur, deserunt neque reprehenderit officiis rem hic sapiente debitis sed quod odit?</p>
            <a href=""><div class="btn">Read More</div></a>    
        </div>
    </section>
    
    <section class="about" id="about">
        <div class="penjelasan">
            <h1>About Us</h1>
            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Nemo minus aut, at dolorum quo perspiciatis assumenda quod architecto tempora, neque ex est explicabo veritatis dicta reiciendis sint a rerum asperiores.
                Lorem ipsum dolor, sit amet consectetur adipisicing elit. Cupiditate nostrum magnam error distinctio odio, perferendis voluptate laboriosam delectus, necessitatibus eos placeat in quae nulla tempore consequatur sed. Molestiae, maxime nulla.</p>
        </div>
    </section>

    <section class="gallery" id="gallery">
        <h1>Gallery</h1>
        <div class="semuagambar">
            <img src="https://images.unsplash.com/photo-1524995997946-a1c2e315a42f?ixid=MnwxMjA3fDB8MHxzZWFyY2h8M3x8ZWR1Y2F0aW9ufGVufDB8fDB8fA%3D%3D&ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=60" alt="gambar1">
            <img src="https://images.unsplash.com/photo-1599249300675-c39f1dd2d6be?ixid=MnwxMjA3fDB8MHxzZWFyY2h8NzR8fGVkdWNhdGlvbnxlbnwwfHwwfHw%3D&ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=60" alt="gambar2">
            <img src="https://images.unsplash.com/photo-1522202176988-66273c2fd55f?ixid=MnwxMjA3fDB8MHxzZWFyY2h8MTd8fGVkdWNhdGlvbnxlbnwwfHwwfHw%3D&ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=60" alt="gambar3">
            <img src="https://images.unsplash.com/photo-1531482615713-2afd69097998?ixid=MnwxMjA3fDB8MHxzZWFyY2h8Mjl8fGVkdWNhdGlvbnxlbnwwfHwwfHw%3D&ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=60" alt="gambar4">
        </div>
    </section>

    <section class="contact" id="contact">
        <h1>Contact Us</h1>
        <div class="semuakontak">
            <div class="logo ig">
                <img src="img/ig.png" alt="Logo Instagram">
                <h2><a href="">Instagram</a></h2>
            </div>
            <div class="logo fb">
                <img src="img/fb.png" alt="Logo Facebook">
                <h2><a href="">Facebook</a></h2>
            </div>
            <div class="logo yt">
                <img src="img/yt.png" alt="Logo YouTube">
                <h2><a href="">YouTube</a></h2>
            </div>
            <div class="logo wa">
                <img src="img/wa.png" alt="Logo WhatsApp">
                <h2><a href="">WhatsApp</a></h2>
            </div>
        </div>
    </section>

    <footer style="text-align: center;font-size:20px;">Copyright &copy; Muhammad Abdurrofi. All right reserved</footer>
    <script src="JS/navbar.js"></script>
</body>
</html>