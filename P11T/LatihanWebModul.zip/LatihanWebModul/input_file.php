<?php
    include 'connection.php';

    if(isset($_REQUEST['submit'])) {
        $tipefile = $_FILES['namafile']['type'];
        if($tipefile == "application/pdf") {
            $judulfile = trim($_REQUEST['judulfile']);
            $nama_file = trim($_FILES['namafile']['name']);

            mysqli_query($koneksi, "INSERT INTO materi (judul_materi) VALUES ('$judulfile')");

            $query = mysqli_query($koneksi, "SELECT id_materi FROM materi ORDER BY id_materi DESC LIMIT 1");
            $data = mysqli_fetch_array($query);

            $namabaru = "file_".$data['id_materi'].".pdf";
            $filetemp = $_FILES['namafile']['tmp_name'];
            $id = $data['id_materi'];

            move_uploaded_file($filetemp, "FileMateri/$namabaru");
            $sql = mysqli_query($koneksi, "UPDATE materi SET nama_materi ='$namabaru' WHERE id_materi='$id'");

            header("Location: controller.php?hlm=materi&berhasil=berhasil");
        } else {
            echo "Gagal Upload, File Bukan PDF <a href='controller.php?hlm=materi'> Kembali </a>";
        }
    }
?>