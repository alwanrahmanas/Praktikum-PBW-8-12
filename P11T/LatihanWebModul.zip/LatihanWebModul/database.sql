-- phpMyAdmin SQL Dump
-- version 4.9.5
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Jun 07, 2021 at 08:32 PM
-- Server version: 10.3.29-MariaDB-log-cll-lve
-- PHP Version: 7.3.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `statist1_daftar`
--

-- --------------------------------------------------------

--
-- Table structure for table `akun`
--

CREATE TABLE `akun` (
  `Id` int(11) NOT NULL,
  `email` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `nama_admin` varchar(255) DEFAULT NULL,
  `role_user` varchar(255) DEFAULT NULL,
  `id_user` int(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `akun`
--

INSERT INTO `akun` (`Id`, `email`, `password`, `nama_admin`, `role_user`, `id_user`) VALUES
(2, 'admin@gmail.com', '$2y$10$AIxith3klXwMIMT/t3CpHOasClDF8l1JWV66U1zob78mXT4wksaJq', 'admin', '0', NULL),
(9901183, 'raisa.farihah@gmail.com', '085248756036', '', '1', 9901183),
(9901184, 'aanhidayattulloh97@gmail.com', '083896506105', '', '1', 9901184),
(9901185, 'dian202884@gmail.com', '085753547390', '', '1', 9901185),
(9901186, 'aamelia.sinaga@gmail.com', '081294926206', '', '1', 9901186),
(9901187, 'mawarsimbolon017@gmail.com', '082238867675', '', '1', 9901187),
(9901188, 'saifulfikri3974@gmail.com', '089630344598', '', '1', 9901188),
(9901189, 'anitatoktil@gmail.com', '082228055506', '', '1', 9901189),
(9901190, 'muhammadsyukrinasution4@gmail.com', '082370223821', '', '1', 9901190),
(9901191, 'riapermatasari003@gmail.com', '081326099357', '', '1', 9901191),
(9901193, 'aufamuhammad135@gmail.com', '085705782769', '', '1', 9901193),
(9901194, 'latifaahhhhh@gmail.com', '085392164499', '', '1', 9901194),
(9901195, 'aulia.fikri85@gmail.com', '087732641715', '', '1', 9901195),
(9901196, 'elsasofia2019@gmail.com', '085795243572', '', '1', 9901196),
(9901197, 'iyuri030117@gmail.com', '082268485788', '', '1', 9901197),
(9901198, 'ghozyhanafi@gmail.com', '081285811641', '', '1', 9901198),
(9901199, 'rakhaarya123@gmail.com', '089638498752', '', '1', 9901199),
(9901200, 'albizakiya2@gmail.com', '085943129687', '', '1', 9901200),
(9901201, 'kartikaannur722@gamil.com', '085798029885', '', '1', 9901201),
(9901202, 'twmeilinda05@gmail.com', '085228422618', '', '1', 9901202),
(9901203, 'patrickfarkhan@gmail.com', '081903220136', '', '1', 9901203),
(9901204, 'rnadya723@gmail.com', '0895383140323', '', '1', 9901204),
(9901205, 'nurisro0410@gmail.com', '083108225723', '', '1', 9901205),
(9901206, 'desielyani0112@gmail.com', '088287562234', '', '1', 9901206),
(9901207, 'siahaanrolyn@gmail.com', '089691575285', '', '1', 9901207);

-- --------------------------------------------------------

--
-- Table structure for table `cicilan_pendaftaran`
--

CREATE TABLE `cicilan_pendaftaran` (
  `Id` int(11) NOT NULL,
  `bukti_pembayaran` varchar(255) DEFAULT NULL,
  `id_detail_pendaftaran` int(11) DEFAULT NULL,
  `nominal` int(11) DEFAULT NULL,
  `tanggal_pembayaran` varchar(255) DEFAULT NULL,
  `status_cicilan` int(11) NOT NULL,
  `cicilan_ke` int(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `detail_pendaftaran`
--

CREATE TABLE `detail_pendaftaran` (
  `Id` int(11) NOT NULL,
  `id_user` int(11) DEFAULT NULL,
  `id_admin` int(11) DEFAULT NULL,
  `tanggal_daftar` datetime DEFAULT NULL,
  `metode_pembayaran_pendaftaran` varchar(255) DEFAULT NULL COMMENT 'metode_pembayaran',
  `kelas` varchar(255) DEFAULT NULL,
  `usia` varchar(255) DEFAULT NULL,
  `status_pendaftaran` varchar(255) DEFAULT NULL,
  `status_kegiatan` int(11) NOT NULL DEFAULT 0,
  `biaya_kegiatan` int(11) DEFAULT 0,
  `tanggal_kegiatan` date DEFAULT NULL,
  `bukti_konfirmasi_pembayaran_kegiatan` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `detail_pendaftaran`
--

INSERT INTO `detail_pendaftaran` (`Id`, `id_user`, `id_admin`, `tanggal_daftar`, `metode_pembayaran_pendaftaran`, `kelas`, `usia`, `status_pendaftaran`, `status_kegiatan`, `biaya_kegiatan`, `tanggal_kegiatan`, `bukti_konfirmasi_pembayaran_kegiatan`) VALUES
(9901183, 9901183, NULL, '2021-04-29 08:51:01', NULL, NULL, NULL, '0', 0, 0, NULL, NULL),
(9901184, 9901184, NULL, '2021-04-29 11:10:37', NULL, NULL, NULL, '0', 0, 0, NULL, NULL),
(9901185, 9901185, NULL, '2021-04-29 14:48:10', NULL, NULL, NULL, '0', 0, 0, NULL, NULL),
(9901186, 9901186, NULL, '2021-04-29 20:43:10', NULL, NULL, NULL, '0', 0, 0, NULL, NULL),
(9901187, 9901187, NULL, '2021-04-30 13:00:14', NULL, NULL, NULL, '0', 0, 0, NULL, NULL),
(9901188, 9901188, NULL, '2021-05-01 06:41:09', NULL, NULL, NULL, '0', 0, 0, NULL, NULL),
(9901189, 9901189, NULL, '2021-05-01 13:08:21', NULL, NULL, NULL, '0', 0, 0, NULL, NULL),
(9901190, 9901190, NULL, '2021-05-02 14:29:43', NULL, NULL, NULL, '0', 0, 0, NULL, NULL),
(9901191, 9901191, NULL, '2021-05-02 20:50:12', NULL, NULL, NULL, '0', 0, 0, NULL, NULL),
(9901193, 9901193, NULL, '2021-05-04 21:13:05', NULL, NULL, NULL, '0', 0, 0, NULL, NULL),
(9901194, 9901194, NULL, '2021-05-05 10:44:22', NULL, NULL, NULL, '0', 0, 0, NULL, NULL),
(9901195, 9901195, NULL, '2021-05-05 12:32:20', NULL, NULL, NULL, '0', 0, 0, NULL, NULL),
(9901196, 9901196, NULL, '2021-05-05 18:51:26', NULL, NULL, NULL, '0', 0, 0, NULL, NULL),
(9901197, 9901197, NULL, '2021-05-05 20:33:46', NULL, NULL, NULL, '0', 0, 0, NULL, NULL),
(9901198, 9901198, NULL, '2021-05-05 20:43:22', NULL, NULL, NULL, '0', 0, 0, NULL, NULL),
(9901199, 9901199, NULL, '2021-05-05 22:09:35', NULL, NULL, NULL, '0', 0, 0, NULL, NULL),
(9901200, 9901200, NULL, '2021-05-06 12:30:41', NULL, NULL, NULL, '0', 0, 0, NULL, NULL),
(9901201, 9901201, NULL, '2021-05-06 13:41:36', NULL, NULL, NULL, '0', 0, 0, NULL, NULL),
(9901202, 9901202, NULL, '2021-05-06 14:27:35', NULL, NULL, NULL, '0', 0, 0, NULL, NULL),
(9901203, 9901203, NULL, '2021-05-06 18:44:33', NULL, NULL, NULL, '0', 0, 0, NULL, NULL),
(9901204, 9901204, NULL, '2021-05-06 20:12:02', NULL, NULL, NULL, '0', 0, 0, NULL, NULL),
(9901205, 9901205, NULL, '2021-05-06 20:49:32', NULL, NULL, NULL, '0', 0, 0, NULL, NULL),
(9901206, 9901206, NULL, '2021-05-06 21:20:17', NULL, NULL, NULL, '0', 0, 0, NULL, NULL),
(9901207, 9901207, NULL, '2021-05-06 21:39:49', NULL, NULL, NULL, '0', 0, 0, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `form`
--

CREATE TABLE `form` (
  `id` int(10) NOT NULL,
  `nama_ujian` varchar(50) NOT NULL,
  `buka_daftar` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `tutup_daftar` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `buka_ujian` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `tutup_ujian` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `form`
--

INSERT INTO `form` (`id`, `nama_ujian`, `buka_daftar`, `tutup_daftar`, `buka_ujian`, `tutup_ujian`) VALUES
(1, 'Try Out Matematika Premium 1.0', '2021-04-28 00:00:00', '2021-05-06 20:00:00', '2021-05-07 00:00:00', '2021-05-09 14:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `guru`
--

CREATE TABLE `guru` (
  `Id` int(11) NOT NULL,
  `nip` char(7) DEFAULT NULL,
  `nama_guru` varchar(100) DEFAULT NULL,
  `alamat` varchar(255) DEFAULT NULL,
  `telp` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `guru`
--

INSERT INTO `guru` (`Id`, `nip`, `nama_guru`, `alamat`, `telp`) VALUES
(2, '1170002', 'Achi', 'Tangerang', '+6285946057839'),
(3, '1170003', 'Test Guru', 'Alamat Guru', '000');

-- --------------------------------------------------------

--
-- Table structure for table `hari`
--

CREATE TABLE `hari` (
  `Id` int(11) NOT NULL,
  `nama_hari` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `hari`
--

INSERT INTO `hari` (`Id`, `nama_hari`) VALUES
(1, 'Senin'),
(2, 'Selasa'),
(3, 'Rabu'),
(4, 'Kamis'),
(5, 'Jumat'),
(6, 'PR');

-- --------------------------------------------------------

--
-- Table structure for table `jadwal`
--

CREATE TABLE `jadwal` (
  `id_jadwal` int(11) NOT NULL,
  `id_hari` int(11) DEFAULT NULL,
  `id_mapel` varchar(255) DEFAULT NULL,
  `kelas` char(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `mapel`
--

CREATE TABLE `mapel` (
  `kode_mapel_kegiatan` char(5) NOT NULL DEFAULT '',
  `nama_mapel_kegiatan` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `pembayaran_spp`
--

CREATE TABLE `pembayaran_spp` (
  `Id` int(11) NOT NULL,
  `tanggal_pembayaran_spp` date DEFAULT NULL,
  `cicilan_ke` int(11) NOT NULL,
  `status_spp` int(11) DEFAULT NULL,
  `user_id` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `pendaftaran`
--

CREATE TABLE `pendaftaran` (
  `Id` int(11) NOT NULL,
  `nama` varchar(50) NOT NULL,
  `jenis_kelamin` char(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `pendaftaran`
--

INSERT INTO `pendaftaran` (`Id`, `nama`, `jenis_kelamin`) VALUES
(9901183, 'RAISA FARIHAH', 'Kalimantan Selatan'),
(9901184, 'Aan Hidayat Tulloh', 'Jawa Tengah'),
(9901185, 'Dian Nur Wijayanti', 'Jawa Tengah'),
(9901186, 'Amanda Amelia', 'Jawa Barat'),
(9901187, 'Mawar Agus Ria Simbolon', 'Sumatera Utara'),
(9901188, 'Saeful Fikri', 'Banten'),
(9901189, 'Anita', 'Jawa Tengah'),
(9901190, 'Syukri', 'Sumatera Utara'),
(9901191, 'Ria Permatasari', 'Jawa Tengah'),
(9901193, 'Muhammad Aufa Hakim', 'Kalimantan Timur'),
(9901194, 'Tfh', 'Kalimantan Tengah'),
(9901195, 'Aulia Fikri Takiyudin', 'Jawa Tengah'),
(9901196, 'Elsa Indra Sofia', 'Jawa Barat'),
(9901197, 'ILDA YUNITA SARI', 'Aceh'),
(9901198, 'Ghozy Hanafi Agung', 'Jawa Barat'),
(9901199, 'Erwin A', 'Jawa Tengah'),
(9901200, 'Zakiyatul Albi', 'Jawa timur'),
(9901201, 'Sri Kartika Annur', 'Jawa Barat'),
(9901202, 'Tri Mei', 'Jawa Tengah'),
(9901203, 'Patrick Farkhanudin ', 'Jawa Tengah'),
(9901204, 'Ruthnadya AK ', 'Jawa Tengah'),
(9901205, 'MOSHI', 'Jawa Tengah'),
(9901206, 'Desi Elyani', 'Sumatera Selatan'),
(9901207, 'Rolyn Abigael', 'Kalimantan Barat');

-- --------------------------------------------------------

--
-- Table structure for table `siswa`
--

CREATE TABLE `siswa` (
  `nis` char(6) NOT NULL DEFAULT '0',
  `kelas` varchar(255) DEFAULT NULL,
  `id_detail_pendaftaran` int(11) DEFAULT NULL,
  `nama` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `akun`
--
ALTER TABLE `akun`
  ADD PRIMARY KEY (`Id`),
  ADD KEY `id_user` (`id_user`),
  ADD KEY `id_user_2` (`id_user`);

--
-- Indexes for table `cicilan_pendaftaran`
--
ALTER TABLE `cicilan_pendaftaran`
  ADD PRIMARY KEY (`Id`),
  ADD KEY `id_detail_pendaftaran` (`id_detail_pendaftaran`);

--
-- Indexes for table `detail_pendaftaran`
--
ALTER TABLE `detail_pendaftaran`
  ADD PRIMARY KEY (`Id`),
  ADD KEY `id_user` (`id_user`),
  ADD KEY `id_admin` (`id_admin`);

--
-- Indexes for table `form`
--
ALTER TABLE `form`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `guru`
--
ALTER TABLE `guru`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `hari`
--
ALTER TABLE `hari`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `jadwal`
--
ALTER TABLE `jadwal`
  ADD PRIMARY KEY (`id_jadwal`),
  ADD KEY `id_mapel` (`id_mapel`),
  ADD KEY `id_hari` (`id_hari`);

--
-- Indexes for table `mapel`
--
ALTER TABLE `mapel`
  ADD PRIMARY KEY (`kode_mapel_kegiatan`);

--
-- Indexes for table `pembayaran_spp`
--
ALTER TABLE `pembayaran_spp`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `pendaftaran`
--
ALTER TABLE `pendaftaran`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `siswa`
--
ALTER TABLE `siswa`
  ADD PRIMARY KEY (`nis`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `akun`
--
ALTER TABLE `akun`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9901208;

--
-- AUTO_INCREMENT for table `cicilan_pendaftaran`
--
ALTER TABLE `cicilan_pendaftaran`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `detail_pendaftaran`
--
ALTER TABLE `detail_pendaftaran`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9901208;

--
-- AUTO_INCREMENT for table `guru`
--
ALTER TABLE `guru`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `hari`
--
ALTER TABLE `hari`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `jadwal`
--
ALTER TABLE `jadwal`
  MODIFY `id_jadwal` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `pembayaran_spp`
--
ALTER TABLE `pembayaran_spp`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `pendaftaran`
--
ALTER TABLE `pendaftaran`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9901208;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `akun`
--
ALTER TABLE `akun`
  ADD CONSTRAINT `akun_ibfk_1` FOREIGN KEY (`id_user`) REFERENCES `pendaftaran` (`Id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `cicilan_pendaftaran`
--
ALTER TABLE `cicilan_pendaftaran`
  ADD CONSTRAINT `cicilan_pendaftaran_ibfk_1` FOREIGN KEY (`id_detail_pendaftaran`) REFERENCES `detail_pendaftaran` (`Id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `detail_pendaftaran`
--
ALTER TABLE `detail_pendaftaran`
  ADD CONSTRAINT `detail_pendaftaran_ibfk_1` FOREIGN KEY (`id_user`) REFERENCES `pendaftaran` (`Id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `detail_pendaftaran_ibfk_2` FOREIGN KEY (`id_admin`) REFERENCES `akun` (`Id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `jadwal`
--
ALTER TABLE `jadwal`
  ADD CONSTRAINT `jadwal_ibfk_1` FOREIGN KEY (`id_mapel`) REFERENCES `mapel` (`kode_mapel_kegiatan`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `jadwal_ibfk_2` FOREIGN KEY (`id_hari`) REFERENCES `hari` (`Id`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
