<?php
    include 'connection.php';
    
    if(isset($_GET['noId'])) {
        $idMember = $_GET['noId'];
        
        function deleteMember($idMember) {
            global $koneksi;
            mysqli_query($koneksi, "DELETE FROM pengguna WHERE noId = '$idMember'");
            $return =  mysqli_affected_rows($koneksi);
            $koneksi = null;
            return $return;
        }

        if(deleteMember($idMember) > 0) {
            echo '
                <script>
                    alert("Data member berhasil dihapus!");
                    document.location.href = "controller.php?hlm=anggota";
                </script>
            ';
        } else {
            echo '
                <script>
                    alert("Data gagal dihapus!");
                    document.location.href = "controller.php?hlm=anggota";
                </script>
            ';
        }
    }
    if(isset($_GET['id_materi'])) {
        $idMateri = $_GET['id_materi'];

        function deleteMateri($idMateri) {
            global $koneksi;
            mysqli_query($koneksi, "DELETE FROM materi WHERE id_materi = '$idMateri'");
            $return =  mysqli_affected_rows($koneksi);
            $koneksi = null;
            return $return;
        }
    
        if(deleteMateri($idMateri) > 0) {
            echo '
                <script>
                    alert("File materi berhasil dihapus!");
                    document.location.href = "controller.php?hlm=materi";
                </script>
            ';
        } else {
            echo '
                <script>
                    alert("File materi gagal dihapus!");
                    document.location.href = "controller.php?hlm=materi";
                </script>
            ';
        }
    }
?>